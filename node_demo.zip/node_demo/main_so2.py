import machine
from machine import Pin, ADC, Timer
from ssd1306 import SSD1306_I2C
import utime
import framebuf

SleepTime = 1.5
# ADC端口定义
dB_pin = 7
adc = ADC(Pin(dB_pin))
adc.atten(ADC.ATTN_11DB)



while True:
  
    print(adc.read_u16())

    v = adc.read_u16() / 65535 * 5.0
    print(v)